// Secure Data Wiping System - JavaScript
class SecureWipeApp {
    constructor() {
        this.currentPage = 'dashboard';
        this.currentWizardStep = 1;
        this.selectedAsset = null;
        this.selectedMethod = null;
        this.wipingInProgress = false;
        
        // Application data
        this.data = {
            assets: [
                {"id": "AST-001", "type": "Laptop", "serial": "LP123456", "status": "Ready", "lastWiped": "2024-09-15"},
                {"id": "AST-002", "type": "Desktop", "serial": "DT789012", "status": "In Progress", "lastWiped": "2024-09-20"},
                {"id": "AST-003", "type": "Server", "serial": "SV345678", "status": "Completed", "lastWiped": "2024-09-25"},
                {"id": "AST-004", "type": "Hard Drive", "serial": "HD901234", "status": "Ready", "lastWiped": "Never"},
                {"id": "AST-005", "type": "SSD", "serial": "SS567890", "status": "Completed", "lastWiped": "2024-09-22"}
            ],
            recentActivities: [
                {"timestamp": "2024-10-02 10:30", "action": "Wiping completed", "asset": "AST-003", "method": "NIST Purge"},
                {"timestamp": "2024-10-02 09:15", "action": "Certificate generated", "asset": "AST-002", "method": "NIST Clear"},
                {"timestamp": "2024-10-01 16:45", "action": "Asset registered", "asset": "AST-005", "method": "N/A"},
                {"timestamp": "2024-10-01 14:20", "action": "Wiping started", "asset": "AST-004", "method": "NIST Destroy"},
                {"timestamp": "2024-10-01 11:30", "action": "Compliance report generated", "asset": "Multiple", "method": "N/A"}
            ],
            wipingMethods: [
                {"id": "clear", "name": "NIST 800-88 Clear", "description": "Logical sanitization for basic protection", "duration": "15-30 minutes"},
                {"id": "purge", "name": "NIST 800-88 Purge", "description": "Physical/logical sanitization for enhanced protection", "duration": "1-3 hours"},
                {"id": "destroy", "name": "NIST 800-88 Destroy", "description": "Physical destruction for maximum security", "duration": "N/A - Physical process"}
            ],
            systemStatus: {
                activeProcesses: 2,
                queuedTasks: 5,
                systemLoad: 45,
                storageUsed: 78
            }
        };
        
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.populateInitialData();
        this.showPage('dashboard');
    }
    
    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.sidebar__item').forEach(item => {
            item.addEventListener('click', (e) => {
                const page = e.currentTarget.dataset.page;
                this.showPage(page);
            });
        });
        
        // Add New Asset button
        this.setupAddAssetButton();
        
        // Wizard navigation
        this.setupWizardNavigation();
        
        // Asset search and filter
        this.setupAssetFilters();
        
        // Modal functionality
        this.setupModal();
        
        // Form submissions
        this.setupFormHandlers();
    }
    
    setupAddAssetButton() {
        // Find the Add New Asset button by its text content and icon
        document.querySelectorAll('.btn--primary').forEach(btn => {
            if (btn.innerHTML.includes('fa-plus') && btn.textContent.trim().includes('Add New Asset')) {
                btn.addEventListener('click', () => this.showAddAssetModal());
            }
        });
    }
    
    showAddAssetModal() {
        const modalContent = `
            <div class="form-group">
                <label class="form-label">Asset Type</label>
                <select class="form-control" id="new-asset-type">
                    <option value="">Select type...</option>
                    <option value="Laptop">Laptop</option>
                    <option value="Desktop">Desktop</option>
                    <option value="Server">Server</option>
                    <option value="Hard Drive">Hard Drive</option>
                    <option value="SSD">SSD</option>
                    <option value="Tablet">Tablet</option>
                    <option value="Phone">Phone</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Serial Number</label>
                <input type="text" class="form-control" id="new-asset-serial" placeholder="Enter serial number">
            </div>
            <div class="form-group">
                <label class="form-label">
                    <input type="checkbox" id="new-asset-urgent"> Mark as urgent for immediate processing
                </label>
            </div>
        `;
        
        // Create custom modal for add asset
        this.showCustomModal('Add New Asset', modalContent, () => this.addNewAsset());
    }
    
    addNewAsset() {
        const type = document.getElementById('new-asset-type')?.value;
        const serial = document.getElementById('new-asset-serial')?.value;
        const urgent = document.getElementById('new-asset-urgent')?.checked;
        
        if (!type || !serial) {
            alert('Please fill in all required fields');
            return false;
        }
        
        // Generate new asset ID
        const newId = `AST-${String(this.data.assets.length + 1).padStart(3, '0')}`;
        
        const newAsset = {
            id: newId,
            type: type,
            serial: serial.toUpperCase(),
            status: 'Ready',
            lastWiped: 'Never'
        };
        
        // Add to data
        this.data.assets.push(newAsset);
        
        // Add to recent activities
        this.data.recentActivities.unshift({
            timestamp: new Date().toLocaleString('en-GB', {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit'
            }).replace(',', ''),
            action: 'Asset registered',
            asset: newId,
            method: 'N/A'
        });
        
        // Update UI
        this.populateAssetsTable();
        this.populateAssetSelect();
        this.populateRecentActivities();
        
        // Show success message
        setTimeout(() => {
            this.showModal(
                'Asset Added Successfully',
                `Asset ${newId} (${type}) has been registered and is ready for processing.${urgent ? ' It has been marked as urgent.' : ''}`
            );
        }, 100);
        
        return true;
    }
    
    showCustomModal(title, bodyHtml, confirmCallback = null) {
        const modal = document.getElementById('confirmation-modal');
        const titleEl = document.getElementById('modal-title');
        const messageEl = document.getElementById('modal-message');
        const confirmBtn = document.getElementById('modal-confirm');
        
        if (titleEl) titleEl.textContent = title;
        if (messageEl) messageEl.innerHTML = bodyHtml;
        
        // Remove existing listeners
        const newConfirmBtn = confirmBtn.cloneNode(true);
        confirmBtn.parentNode.replaceChild(newConfirmBtn, confirmBtn);
        
        newConfirmBtn.textContent = confirmCallback ? 'Add Asset' : 'OK';
        
        if (confirmCallback) {
            newConfirmBtn.addEventListener('click', () => {
                if (confirmCallback()) {
                    this.closeModal();
                }
            });
        } else {
            newConfirmBtn.addEventListener('click', () => this.closeModal());
        }
        
        modal.classList.remove('hidden');
    }
    
    setupWizardNavigation() {
        // Use setTimeout to ensure DOM elements are ready
        setTimeout(() => {
            this.initializeWizardElements();
        }, 100);
    }
    
    initializeWizardElements() {
        // Step 1: Asset selection
        const assetSelect = document.getElementById('wipe-asset-select');
        const nextStep1 = document.getElementById('next-step-1');
        
        if (assetSelect) {
            // Remove any existing event listeners
            const newAssetSelect = assetSelect.cloneNode(true);
            assetSelect.parentNode.replaceChild(newAssetSelect, assetSelect);
            
            newAssetSelect.addEventListener('change', (e) => {
                const assetId = e.target.value;
                console.log('Asset selected:', assetId); // Debug log
                
                if (assetId) {
                    this.selectedAsset = this.data.assets.find(asset => asset.id === assetId);
                    console.log('Selected asset object:', this.selectedAsset); // Debug log
                    
                    if (this.selectedAsset) {
                        this.showAssetDetails(this.selectedAsset);
                        if (nextStep1) {
                            nextStep1.disabled = false;
                        }
                    }
                } else {
                    this.selectedAsset = null;
                    const assetDetails = document.getElementById('asset-details');
                    if (assetDetails) {
                        assetDetails.style.display = 'none';
                    }
                    if (nextStep1) {
                        nextStep1.disabled = true;
                    }
                }
            });
        }
        
        if (nextStep1) {
            // Remove existing event listeners and add new one
            const newNextStep1 = nextStep1.cloneNode(true);
            nextStep1.parentNode.replaceChild(newNextStep1, nextStep1);
            
            newNextStep1.addEventListener('click', () => {
                console.log('Next step 1 clicked, selected asset:', this.selectedAsset); // Debug log
                this.goToWizardStep(2);
            });
        }
        
        // Step 2: Method selection
        const prevStep2 = document.getElementById('prev-step-2');
        const nextStep2 = document.getElementById('next-step-2');
        
        if (prevStep2) {
            prevStep2.addEventListener('click', () => this.goToWizardStep(1));
        }
        
        if (nextStep2) {
            nextStep2.addEventListener('click', () => this.goToWizardStep(3));
        }
        
        // Step 3: Configuration
        const prevStep3 = document.getElementById('prev-step-3');
        const nextStep3 = document.getElementById('next-step-3');
        
        if (prevStep3) {
            prevStep3.addEventListener('click', () => this.goToWizardStep(2));
        }
        
        if (nextStep3) {
            nextStep3.addEventListener('click', () => this.goToWizardStep(4));
        }
        
        // Step 4: Execution
        const prevStep4 = document.getElementById('prev-step-4');
        const startWipe = document.getElementById('start-wipe');
        
        if (prevStep4) {
            prevStep4.addEventListener('click', () => this.goToWizardStep(3));
        }
        
        if (startWipe) {
            startWipe.addEventListener('click', () => this.startWiping());
        }
    }
    
    setupAssetFilters() {
        const searchInput = document.getElementById('asset-search');
        const filterSelect = document.getElementById('asset-filter');
        
        if (searchInput) {
            searchInput.addEventListener('input', () => this.filterAssets());
        }
        
        if (filterSelect) {
            filterSelect.addEventListener('change', () => this.filterAssets());
        }
    }
    
    setupModal() {
        const modal = document.getElementById('confirmation-modal');
        const closeBtn = modal?.querySelector('.modal__close');
        const cancelBtn = document.getElementById('modal-cancel');
        const overlay = modal?.querySelector('.modal__overlay');
        
        [closeBtn, cancelBtn, overlay].forEach(element => {
            element?.addEventListener('click', () => this.closeModal());
        });
    }
    
    setupFormHandlers() {
        // Generate certificate button
        document.querySelectorAll('.btn--primary').forEach(btn => {
            if (btn.textContent.trim() === 'Generate Certificate') {
                btn.addEventListener('click', () => this.generateCertificate());
            }
        });
        
        // Export buttons
        document.querySelectorAll('.btn--outline').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const text = e.target.textContent.trim();
                if (text.includes('PDF') || text.includes('CSV') || text.includes('Excel')) {
                    this.exportData(text);
                }
            });
        });
    }
    
    populateInitialData() {
        this.populateRecentActivities();
        this.populateAssetsTable();
        this.populateAssetSelect();
        this.populateWipingMethods();
        this.updateSystemStatus();
    }
    
    populateRecentActivities() {
        const activityList = document.getElementById('activity-list');
        if (!activityList) return;
        
        activityList.innerHTML = this.data.recentActivities.map(activity => `
            <li class="activity-item">
                <div>
                    <strong>${activity.action}</strong>
                    <br>
                    <small>Asset: ${activity.asset} | Method: ${activity.method}</small>
                </div>
                <span class="activity-time">${activity.timestamp}</span>
            </li>
        `).join('');
    }
    
    populateAssetsTable() {
        const tbody = document.getElementById('assets-table');
        if (!tbody) return;
        
        tbody.innerHTML = this.data.assets.map(asset => `
            <tr>
                <td>${asset.id}</td>
                <td>${asset.type}</td>
                <td>${asset.serial}</td>
                <td><span class="status--${asset.status.toLowerCase().replace(' ', '-')}">${asset.status}</span></td>
                <td>${asset.lastWiped}</td>
                <td>
                    <button class="btn btn--sm action-btn" onclick="app.viewAsset('${asset.id}')">View</button>
                    <button class="btn btn--sm btn--primary action-btn" onclick="app.wipeAsset('${asset.id}')">Wipe</button>
                </td>
            </tr>
        `).join('');
    }
    
    populateAssetSelect() {
        const select = document.getElementById('wipe-asset-select');
        if (!select) return;
        
        const readyAssets = this.data.assets.filter(asset => asset.status === 'Ready');
        select.innerHTML = '<option value="">Choose an asset...</option>' + 
            readyAssets.map(asset => `
                <option value="${asset.id}">${asset.id} - ${asset.type} (${asset.serial})</option>
            `).join('');
            
        console.log('Asset select populated with', readyAssets.length, 'ready assets'); // Debug log
    }
    
    populateWipingMethods() {
        const container = document.getElementById('method-selection');
        if (!container) return;
        
        container.innerHTML = this.data.wipingMethods.map(method => `
            <div class="method-card" data-method="${method.id}">
                <h4>${method.name}</h4>
                <p>${method.description}</p>
                <div class="method-duration">Estimated Duration: ${method.duration}</div>
            </div>
        `).join('');
        
        // Add click handlers for method selection
        container.querySelectorAll('.method-card').forEach(card => {
            card.addEventListener('click', () => {
                container.querySelectorAll('.method-card').forEach(c => c.classList.remove('selected'));
                card.classList.add('selected');
                
                const methodId = card.dataset.method;
                this.selectedMethod = this.data.wipingMethods.find(m => m.id === methodId);
                
                const nextStep2 = document.getElementById('next-step-2');
                if (nextStep2) {
                    nextStep2.disabled = false;
                }
            });
        });
    }
    
    updateSystemStatus() {
        const activeProcessesEl = document.getElementById('active-processes');
        const queuedTasksEl = document.getElementById('queued-tasks');
        
        if (activeProcessesEl) {
            activeProcessesEl.textContent = this.data.systemStatus.activeProcesses;
        }
        if (queuedTasksEl) {
            queuedTasksEl.textContent = this.data.systemStatus.queuedTasks;
        }
    }
    
    showPage(pageId) {
        // Update sidebar
        document.querySelectorAll('.sidebar__item').forEach(item => {
            item.classList.remove('active');
            if (item.dataset.page === pageId) {
                item.classList.add('active');
            }
        });
        
        // Update content
        document.querySelectorAll('.page').forEach(page => {
            page.classList.remove('active');
        });
        
        const targetPage = document.getElementById(`${pageId}-page`);
        if (targetPage) {
            targetPage.classList.add('active');
            this.currentPage = pageId;
        }
        
        // Reset wizard if navigating to wiping page and re-initialize
        if (pageId === 'wiping') {
            this.resetWizard();
            // Re-setup wizard after a short delay to ensure DOM is ready
            setTimeout(() => {
                this.initializeWizardElements();
            }, 50);
        }
    }
    
    showAssetDetails(asset) {
        const detailsDiv = document.getElementById('asset-details');
        if (!detailsDiv || !asset) return;
        
        detailsDiv.innerHTML = `
            <h4>Asset Details</h4>
            <div class="summary-item">
                <span>Asset ID:</span>
                <strong>${asset.id}</strong>
            </div>
            <div class="summary-item">
                <span>Device Type:</span>
                <strong>${asset.type}</strong>
            </div>
            <div class="summary-item">
                <span>Serial Number:</span>
                <strong>${asset.serial}</strong>
            </div>
            <div class="summary-item">
                <span>Current Status:</span>
                <strong>${asset.status}</strong>
            </div>
            <div class="summary-item">
                <span>Last Wiped:</span>
                <strong>${asset.lastWiped}</strong>
            </div>
        `;
        detailsDiv.style.display = 'block';
    }
    
    goToWizardStep(step) {
        // Update step indicators
        document.querySelectorAll('.step').forEach((stepEl, index) => {
            stepEl.classList.toggle('active', index + 1 <= step);
        });
        
        // Update step content
        document.querySelectorAll('.wizard-step').forEach((stepEl, index) => {
            stepEl.classList.toggle('active', index + 1 === step);
        });
        
        this.currentWizardStep = step;
        
        // Populate step 4 summary
        if (step === 4) {
            this.populateWipingSummary();
        }
    }
    
    populateWipingSummary() {
        const summaryDiv = document.getElementById('wiping-summary');
        if (!summaryDiv || !this.selectedAsset || !this.selectedMethod) return;
        
        summaryDiv.innerHTML = `
            <h4>Wiping Summary</h4>
            <div class="summary-item">
                <span>Asset:</span>
                <strong>${this.selectedAsset.id} - ${this.selectedAsset.type}</strong>
            </div>
            <div class="summary-item">
                <span>Serial Number:</span>
                <strong>${this.selectedAsset.serial}</strong>
            </div>
            <div class="summary-item">
                <span>Method:</span>
                <strong>${this.selectedMethod.name}</strong>
            </div>
            <div class="summary-item">
                <span>Estimated Duration:</span>
                <strong>${this.selectedMethod.duration}</strong>
            </div>
            <div class="summary-item">
                <span>Verification Passes:</span>
                <strong>3 Passes (Enhanced)</strong>
            </div>
            <div class="summary-item">
                <span>Certificate Generation:</span>
                <strong>Enabled</strong>
            </div>
        `;
    }
    
    startWiping() {
        if (this.wipingInProgress) return;
        
        this.showModal(
            'Confirm Data Wiping',
            `Are you absolutely sure you want to start data wiping for ${this.selectedAsset.id}? This action cannot be undone and will permanently destroy all data on the device.`,
            () => this.executeWiping()
        );
    }
    
    executeWiping() {
        this.wipingInProgress = true;
        
        // Show progress section
        const progressSection = document.getElementById('progress-section');
        const startBtn = document.getElementById('start-wipe');
        const prevBtn = document.getElementById('prev-step-4');
        
        if (progressSection) progressSection.style.display = 'block';
        if (startBtn) {
            startBtn.disabled = true;
            startBtn.textContent = 'Wiping in Progress...';
        }
        if (prevBtn) prevBtn.disabled = true;
        
        // Simulate wiping progress
        this.simulateWipingProgress();
    }
    
    simulateWipingProgress() {
        const progressFill = document.getElementById('wipe-progress');
        const progressText = document.getElementById('progress-text');
        
        const phases = [
            { progress: 10, text: 'Initializing secure wiping process...' },
            { progress: 25, text: 'Performing initial data overwrite...' },
            { progress: 50, text: 'Executing verification pass 1/3...' },
            { progress: 75, text: 'Executing verification pass 2/3...' },
            { progress: 90, text: 'Executing verification pass 3/3...' },
            { progress: 100, text: 'Data wiping completed successfully!' }
        ];
        
        let currentPhase = 0;
        
        const updateProgress = () => {
            if (currentPhase < phases.length) {
                const phase = phases[currentPhase];
                if (progressFill) progressFill.style.width = `${phase.progress}%`;
                if (progressText) progressText.textContent = phase.text;
                
                currentPhase++;
                setTimeout(updateProgress, 2000);
            } else {
                this.completeWiping();
            }
        };
        
        updateProgress();
    }
    
    completeWiping() {
        // Update asset status
        if (this.selectedAsset) {
            const asset = this.data.assets.find(a => a.id === this.selectedAsset.id);
            if (asset) {
                asset.status = 'Completed';
                asset.lastWiped = new Date().toISOString().split('T')[0];
            }
        }
        
        // Add to recent activities
        this.data.recentActivities.unshift({
            timestamp: new Date().toLocaleString('en-GB', {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit'
            }).replace(',', ''),
            action: 'Wiping completed',
            asset: this.selectedAsset.id,
            method: this.selectedMethod.name
        });
        
        // Update UI
        this.populateAssetsTable();
        this.populateRecentActivities();
        
        // Show success message
        setTimeout(() => {
            this.showModal(
                'Wiping Completed',
                `Data wiping for ${this.selectedAsset.id} has been completed successfully. A compliance certificate has been generated and is available in the Reports section.`,
                () => {
                    this.resetWizard();
                    this.showPage('dashboard');
                }
            );
        }, 1000);
        
        this.wipingInProgress = false;
    }
    
    resetWizard() {
        this.currentWizardStep = 1;
        this.selectedAsset = null;
        this.selectedMethod = null;
        this.wipingInProgress = false;
        
        // Reset UI
        this.goToWizardStep(1);
        
        const assetSelect = document.getElementById('wipe-asset-select');
        if (assetSelect) assetSelect.selectedIndex = 0;
        
        const assetDetails = document.getElementById('asset-details');
        if (assetDetails) assetDetails.style.display = 'none';
        
        const nextStep1 = document.getElementById('next-step-1');
        if (nextStep1) nextStep1.disabled = true;
        
        const nextStep2 = document.getElementById('next-step-2');
        if (nextStep2) nextStep2.disabled = true;
        
        const progressSection = document.getElementById('progress-section');
        if (progressSection) progressSection.style.display = 'none';
        
        const startBtn = document.getElementById('start-wipe');
        if (startBtn) {
            startBtn.disabled = false;
            startBtn.textContent = 'Start Data Wiping';
        }
        
        const prevBtn = document.getElementById('prev-step-4');
        if (prevBtn) prevBtn.disabled = false;
        
        // Clear method selection
        document.querySelectorAll('.method-card').forEach(card => {
            card.classList.remove('selected');
        });
        
        // Reset progress
        const progressFill = document.getElementById('wipe-progress');
        if (progressFill) progressFill.style.width = '0%';
        
        const progressText = document.getElementById('progress-text');
        if (progressText) progressText.textContent = 'Initializing...';
        
        // Repopulate asset select in case status changed
        this.populateAssetSelect();
    }
    
    filterAssets() {
        const searchTerm = document.getElementById('asset-search')?.value.toLowerCase() || '';
        const typeFilter = document.getElementById('asset-filter')?.value || '';
        
        const filteredAssets = this.data.assets.filter(asset => {
            const matchesSearch = asset.id.toLowerCase().includes(searchTerm) ||
                                asset.type.toLowerCase().includes(searchTerm) ||
                                asset.serial.toLowerCase().includes(searchTerm);
            
            const matchesType = !typeFilter || asset.type === typeFilter;
            
            return matchesSearch && matchesType;
        });
        
        this.renderFilteredAssets(filteredAssets);
    }
    
    renderFilteredAssets(assets) {
        const tbody = document.getElementById('assets-table');
        if (!tbody) return;
        
        tbody.innerHTML = assets.map(asset => `
            <tr>
                <td>${asset.id}</td>
                <td>${asset.type}</td>
                <td>${asset.serial}</td>
                <td><span class="status--${asset.status.toLowerCase().replace(' ', '-')}">${asset.status}</span></td>
                <td>${asset.lastWiped}</td>
                <td>
                    <button class="btn btn--sm action-btn" onclick="app.viewAsset('${asset.id}')">View</button>
                    <button class="btn btn--sm btn--primary action-btn" onclick="app.wipeAsset('${asset.id}')">Wipe</button>
                </td>
            </tr>
        `).join('');
    }
    
    showModal(title, message, confirmCallback = null) {
        const modal = document.getElementById('confirmation-modal');
        const titleEl = document.getElementById('modal-title');
        const messageEl = document.getElementById('modal-message');
        const confirmBtn = document.getElementById('modal-confirm');
        
        if (titleEl) titleEl.textContent = title;
        if (messageEl) messageEl.textContent = message;
        
        // Remove existing listeners
        const newConfirmBtn = confirmBtn.cloneNode(true);
        confirmBtn.parentNode.replaceChild(newConfirmBtn, confirmBtn);
        
        newConfirmBtn.textContent = 'Confirm';
        
        if (confirmCallback) {
            newConfirmBtn.addEventListener('click', () => {
                confirmCallback();
                this.closeModal();
            });
        } else {
            newConfirmBtn.addEventListener('click', () => this.closeModal());
        }
        
        modal.classList.remove('hidden');
    }
    
    closeModal() {
        const modal = document.getElementById('confirmation-modal');
        if (modal) {
            modal.classList.add('hidden');
        }
    }
    
    // Asset action handlers
    viewAsset(assetId) {
        const asset = this.data.assets.find(a => a.id === assetId);
        if (asset) {
            this.showModal(
                `Asset Details - ${asset.id}`,
                `Type: ${asset.type}\nSerial: ${asset.serial}\nStatus: ${asset.status}\nLast Wiped: ${asset.lastWiped}`
            );
        }
    }
    
    wipeAsset(assetId) {
        const asset = this.data.assets.find(a => a.id === assetId);
        if (asset && asset.status === 'Ready') {
            this.showPage('wiping');
            
            setTimeout(() => {
                const assetSelect = document.getElementById('wipe-asset-select');
                if (assetSelect) {
                    assetSelect.value = assetId;
                    assetSelect.dispatchEvent(new Event('change'));
                }
            }, 200);
        } else {
            this.showModal(
                'Asset Not Available',
                `Asset ${assetId} is not ready for wiping. Current status: ${asset ? asset.status : 'Unknown'}`
            );
        }
    }
    
    generateCertificate() {
        this.showModal(
            'Certificate Generated',
            'Compliance certificate has been generated successfully and is available for download.'
        );
    }
    
    exportData(format) {
        this.showModal(
            'Export Initiated',
            `Data export in ${format} format has been initiated. The file will be available for download shortly.`
        );
    }
}

// Initialize the application
let app;

// Add some utility functions for demo purposes
window.addEventListener('load', () => {
    // Initialize the app
    app = new SecureWipeApp();
    
    // Add some interactive hover effects
    document.querySelectorAll('.stat-card').forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'translateY(-2px)';
            card.style.boxShadow = 'var(--shadow-md)';
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translateY(0)';
            card.style.boxShadow = 'var(--shadow-sm)';
        });
    });
    
    // Add dynamic time updates
    setInterval(() => {
        const now = new Date();
        const timeString = now.toLocaleString('en-GB', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        }).replace(',', '');
        
        // Update any dynamic timestamps if needed
        document.querySelectorAll('.activity-time').forEach((el, index) => {
            if (index === 0) {
                // Update the most recent activity time occasionally
                if (Math.random() < 0.1) { // 10% chance every interval
                    el.textContent = timeString;
                }
            }
        });
    }, 30000); // Update every 30 seconds
});