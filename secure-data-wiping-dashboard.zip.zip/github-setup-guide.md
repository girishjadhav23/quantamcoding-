# GitHub Repository Setup and Deployment Guide

## Part 1: Setting Up GitHub Repository

### 1. Create GitHub Account
- Visit [github.com](https://github.com)
- Sign up for a free account
- Verify your email address

### 2. Create New Repository

#### Method 1: Through GitHub Website
1. Click the "+" icon in top-right corner
2. Select "New repository"
3. Repository name: `secure-data-wiping-gui`
4. Description: "Frontend GUI for Secure IT Asset Data Wiping and Recycling"
5. Choose "Public" (for free GitHub Pages hosting)
6. Check "Add a README file"
7. Add `.gitignore` template: "Node"
8. Choose license: "MIT License" (recommended)
9. Click "Create repository"

#### Method 2: Using GitHub CLI
```bash
# Install GitHub CLI first: https://cli.github.com/
gh auth login
gh repo create secure-data-wiping-gui --public --description "Frontend GUI for Secure IT Asset Data Wiping and Recycling"
```

### 3. Clone Repository to Local Machine
```bash
git clone https://github.com/YOUR_USERNAME/secure-data-wiping-gui.git
cd secure-data-wiping-gui
```

## Part 2: Local Project Setup

### 1. Initialize React Project
```bash
# Create Vite React project
npm create vite@latest . --template react

# Install dependencies
npm install

# Install additional packages for our application
npm install @mui/material @emotion/react @emotion/styled @mui/icons-material
npm install react-router-dom @reduxjs/toolkit react-redux
npm install react-hook-form yup @hookform/resolvers
npm install axios chart.js react-chartjs-2
npm install jspdf html2canvas date-fns
```

### 2. Create Project Structure
```bash
# Create directory structure
mkdir -p src/components/{common,dashboard,asset-management,wiping,reporting,settings}
mkdir -p src/{pages,services,utils,styles,assets/images}
mkdir -p public docs config
```

### 3. Update package.json for GitHub Pages
```json
{
  "name": "secure-data-wiping-gui",
  "homepage": "https://YOUR_USERNAME.github.io/secure-data-wiping-gui",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview",
    "predeploy": "npm run build",
    "deploy": "gh-pages -d dist"
  },
  "devDependencies": {
    "gh-pages": "^6.0.0"
  }
}
```

### 4. Configure Vite for GitHub Pages
Update `vite.config.js`:
```javascript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  base: '/secure-data-wiping-gui/',
  build: {
    outDir: 'dist',
    assetsDir: 'assets'
  }
})
```

## Part 3: Git Configuration and Initial Commit

### 1. Configure Git (First Time Setup)
```bash
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"
```

### 2. Add Remote Origin (if not cloned)
```bash
git remote add origin https://github.com/YOUR_USERNAME/secure-data-wiping-gui.git
```

### 3. Create and Commit Initial Files
```bash
# Add all files
git add .

# Create initial commit
git commit -m "Initial commit: Setup React project with Vite"

# Push to GitHub
git push -u origin main
```

## Part 4: GitHub Pages Deployment Setup

### Method 1: Using GitHub Actions (Recommended)

1. Create `.github/workflows/deploy.yml`:
```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    
    steps:
    - name: Checkout
      uses: actions/checkout@v4
      
    - name: Setup Node.js
      uses: actions/setup-node@v4
      with:
        node-version: '18'
        cache: 'npm'
        
    - name: Install dependencies
      run: npm ci
      
    - name: Build project
      run: npm run build
      
    - name: Deploy to GitHub Pages
      uses: peaceiris/actions-gh-pages@v3
      if: github.ref == 'refs/heads/main'
      with:
        github_token: ${{ secrets.GITHUB_TOKEN }}
        publish_dir: ./dist
```

2. Enable GitHub Pages:
   - Go to repository Settings
   - Scroll to "Pages" section
   - Source: "GitHub Actions"
   - Save settings

### Method 2: Using gh-pages Package

1. Install gh-pages:
```bash
npm install --save-dev gh-pages
```

2. Add deploy script to package.json:
```json
{
  "scripts": {
    "predeploy": "npm run build",
    "deploy": "gh-pages -d dist"
  }
}
```

3. Deploy:
```bash
npm run deploy
```

4. Configure GitHub Pages:
   - Go to Settings → Pages
   - Source: "Deploy from branch"
   - Branch: "gh-pages"
   - Folder: "/ (root)"

## Part 5: Development Workflow

### 1. Daily Development Process
```bash
# Pull latest changes
git pull origin main

# Create feature branch
git checkout -b feature/new-component

# Make changes and test locally
npm run dev

# Stage and commit changes
git add .
git commit -m "Add: New component for data wiping interface"

# Push to GitHub
git push origin feature/new-component

# Create Pull Request on GitHub
# Merge after review
# Delete feature branch
git checkout main
git branch -d feature/new-component
```

### 2. Continuous Deployment
Every push to main branch will automatically:
1. Run GitHub Actions workflow
2. Build the project
3. Deploy to GitHub Pages
4. Update live site at: `https://YOUR_USERNAME.github.io/secure-data-wiping-gui`

## Part 6: Repository Management

### 1. Branch Protection Rules
1. Go to Settings → Branches
2. Add rule for main branch:
   - Require pull request reviews
   - Require status checks to pass
   - Require branches to be up to date

### 2. Issue Templates
Create `.github/ISSUE_TEMPLATE/bug_report.md`:
```markdown
---
name: Bug report
about: Create a report to help us improve
title: '[BUG] '
labels: bug
assignees: ''
---

**Describe the bug**
A clear description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior.

**Expected behavior**
What you expected to happen.

**Screenshots**
If applicable, add screenshots.
```

### 3. Pull Request Template
Create `.github/pull_request_template.md`:
```markdown
## Description
Brief description of changes.

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update

## Testing
- [ ] Tested locally
- [ ] Added unit tests
- [ ] Updated documentation

## Checklist
- [ ] Code follows project style guidelines
- [ ] Self-review completed
- [ ] Changes generate no new warnings
```

## Part 7: Environment Variables and Secrets

### 1. Environment Variables
Create `.env.example`:
```env
VITE_API_BASE_URL=https://api.example.com
VITE_APP_NAME=Secure Data Wiping GUI
VITE_VERSION=1.0.0
```

### 2. GitHub Secrets (for sensitive data)
1. Go to Settings → Secrets and variables → Actions
2. Add repository secrets:
   - `API_KEY`
   - `DATABASE_URL`
   - etc.

### 3. Use in GitHub Actions:
```yaml
- name: Build with secrets
  run: npm run build
  env:
    VITE_API_KEY: ${{ secrets.API_KEY }}
```

## Part 8: Monitoring and Analytics

### 1. GitHub Insights
- Monitor traffic, clones, and views
- Track popular content and referrers
- Analyze contributor activity

### 2. Dependabot Setup
Create `.github/dependabot.yml`:
```yaml
version: 2
updates:
  - package-ecosystem: "npm"
    directory: "/"
    schedule:
      interval: "weekly"
    open-pull-requests-limit: 10
```

## Part 9: Documentation Structure

### 1. README.md Structure
```markdown
# Secure Data Wiping GUI

## Description
Frontend interface for secure IT asset data wiping and recycling management.

## Features
- NIST 800-88 compliant data sanitization
- Real-time wiping progress tracking
- Certificate generation and audit logs
- Asset management dashboard

## Installation
\`\`\`bash
npm install
npm run dev
\`\`\`

## Deployment
\`\`\`bash
npm run build
npm run deploy
\`\`\`

## Contributing
See CONTRIBUTING.md for guidelines.

## License
MIT License - see LICENSE file.
```

### 2. Additional Documentation
- `docs/API.md` - API documentation
- `docs/DEPLOYMENT.md` - Deployment guide
- `docs/ARCHITECTURE.md` - System architecture
- `CONTRIBUTING.md` - Contribution guidelines
- `CHANGELOG.md` - Version history

## Part 10: Backup and Security

### 1. Repository Backup
- Enable automatic backups through GitHub
- Clone to multiple locations
- Use GitHub's export feature

### 2. Security Best Practices
- Never commit sensitive data
- Use `.gitignore` properly
- Enable two-factor authentication
- Review permissions regularly
- Use signed commits

### 3. Security Features
```bash
# Enable signed commits
git config --global commit.gpgsign true
git config --global user.signingkey YOUR_GPG_KEY
```

This comprehensive guide covers the complete process of setting up a GitHub repository, configuring deployment, and managing the development workflow for your secure data wiping GUI project.