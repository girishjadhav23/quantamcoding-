# VS Code Setup Guide for Secure Data Wiping GUI Development

## Initial Setup

### 1. Install VS Code
- Download from [https://code.visualstudio.com/](https://code.visualstudio.com/)
- Install with default settings
- Launch VS Code

### 2. Essential Extensions for Web Development

#### Core Extensions
- **Live Server** - Real-time preview of HTML/CSS changes
- **ES7+ React/Redux/React-Native snippets** - Code snippets for React
- **Prettier - Code formatter** - Automatic code formatting
- **ESLint** - JavaScript/TypeScript linting
- **Auto Rename Tag** - Automatically rename paired HTML/JSX tags
- **Auto Close Tag** - Automatically add closing tags
- **Bracket Pair Colorizer 2** - Color matching brackets
- **GitLens** - Enhanced Git capabilities

#### React/Frontend Specific
- **Simple React Snippets** - Additional React snippets
- **CSS Peek** - Navigate to CSS definitions
- **HTML CSS Support** - Enhanced CSS intellisense
- **Path Intellisense** - Autocomplete filenames
- **Material Icon Theme** - Better file icons
- **Thunder Client** - REST API testing

### 3. VS Code Settings Configuration

```json
{
  "editor.fontSize": 14,
  "editor.fontFamily": "Fira Code, Consolas, monospace",
  "editor.fontLigatures": true,
  "editor.wordWrap": "on",
  "editor.minimap.enabled": false,
  "editor.formatOnSave": true,
  "editor.defaultFormatter": "esbenp.prettier-vscode",
  "editor.codeActionsOnSave": {
    "source.fixAll.eslint": true
  },
  "emmet.includeLanguages": {
    "javascript": "javascriptreact"
  },
  "files.autoSave": "afterDelay",
  "explorer.confirmDelete": false,
  "workbench.iconTheme": "material-icon-theme",
  "terminal.integrated.defaultProfile.windows": "Git Bash"
}
```

## Project Setup Steps

### 1. Create Project Directory
```bash
mkdir secure-data-wiping-gui
cd secure-data-wiping-gui
```

### 2. Initialize React Project with Vite
```bash
npm create vite@latest . --template react
npm install
```

### 3. Install Required Dependencies
```bash
# UI Framework
npm install @mui/material @emotion/react @emotion/styled
npm install @mui/icons-material

# Routing
npm install react-router-dom

# State Management
npm install @reduxjs/toolkit react-redux

# Form Handling
npm install react-hook-form yup @hookform/resolvers

# HTTP Client
npm install axios

# Charts
npm install chart.js react-chartjs-2

# PDF Generation
npm install jspdf html2canvas

# Utilities
npm install date-fns lodash

# Development Dependencies
npm install -D eslint prettier eslint-config-prettier eslint-plugin-react
```

### 4. Setup ESLint and Prettier
Create `.eslintrc.json`:
```json
{
  "extends": [
    "eslint:recommended",
    "@vitejs/eslint-config-react",
    "prettier"
  ],
  "rules": {
    "react/prop-types": "off",
    "no-unused-vars": "warn"
  }
}
```

Create `.prettierrc`:
```json
{
  "semi": true,
  "trailingComma": "es5",
  "singleQuote": true,
  "printWidth": 80,
  "tabWidth": 2
}
```

### 5. Setup Environment Configuration
Create `.env.example`:
```env
VITE_API_BASE_URL=http://localhost:3001
VITE_APP_NAME=Secure Data Wiping GUI
VITE_ENVIRONMENT=development
```

## VS Code Workspace Configuration

### 1. Create Workspace Settings
Create `.vscode/settings.json`:
```json
{
  "editor.defaultFormatter": "esbenp.prettier-vscode",
  "editor.formatOnSave": true,
  "editor.codeActionsOnSave": {
    "source.fixAll.eslint": true
  },
  "files.associations": {
    "*.jsx": "javascriptreact"
  },
  "emmet.includeLanguages": {
    "javascript": "javascriptreact"
  }
}
```

### 2. Setup Debug Configuration
Create `.vscode/launch.json`:
```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Launch Chrome",
      "request": "launch",
      "type": "node",
      "program": "${workspaceFolder}/node_modules/.bin/vite",
      "args": ["--port", "3000"],
      "console": "integratedTerminal",
      "internalConsoleOptions": "neverOpen"
    }
  ]
}
```

### 3. Setup Tasks
Create `.vscode/tasks.json`:
```json
{
  "version": "2.0.0",
  "tasks": [
    {
      "label": "npm install",
      "type": "shell",
      "command": "npm install",
      "group": "build"
    },
    {
      "label": "npm run dev",
      "type": "shell",
      "command": "npm run dev",
      "group": {
        "kind": "build",
        "isDefault": true
      }
    },
    {
      "label": "npm run build",
      "type": "shell",
      "command": "npm run build",
      "group": "build"
    }
  ]
}
```

## Keyboard Shortcuts Setup

### Essential Shortcuts
- `Ctrl+Shift+P` - Command Palette
- `Ctrl+Shift+E` - Explorer
- `Ctrl+Shift+F` - Search
- `Ctrl+Shift+G` - Source Control
- `Ctrl+Shift+D` - Debug
- `Ctrl+`` ` - Terminal
- `Alt+Shift+F` - Format Document
- `Ctrl+Shift+I` - Developer Tools

### Custom Keybindings
Add to `keybindings.json`:
```json
[
  {
    "key": "ctrl+alt+r",
    "command": "workbench.action.reloadWindow"
  },
  {
    "key": "ctrl+alt+n",
    "command": "explorer.newFile"
  }
]
```

## Development Workflow

### 1. Daily Workflow
1. Open VS Code
2. Open integrated terminal (`Ctrl+``)
3. Run `npm run dev`
4. Open browser to localhost:3000
5. Start coding with live reload

### 2. Git Integration
- Initialize repository: `git init`
- Stage changes: `Ctrl+Shift+G` then click `+`
- Commit: Write message and `Ctrl+Enter`
- Push: Use source control panel

### 3. Debugging
- Set breakpoints by clicking line numbers
- Press `F5` to start debugging
- Use Debug Console for variable inspection

## Performance Tips

### 1. VS Code Optimization
- Disable unnecessary extensions
- Use workspace-specific settings
- Exclude node_modules from search
- Use file watchers efficiently

### 2. Development Optimization
- Use React Developer Tools extension
- Enable Hot Module Replacement
- Optimize bundle size with build analysis
- Use lazy loading for components

## Troubleshooting

### Common Issues
1. **Extensions not working**: Reload window (`Ctrl+Shift+P` -> "Reload Window")
2. **Eslint errors**: Check `.eslintrc.json` configuration
3. **Import errors**: Verify file paths and extensions
4. **Build failures**: Clear node_modules and reinstall

### Performance Issues
1. **Slow IntelliSense**: Exclude large directories from workspace
2. **High memory usage**: Disable unused extensions
3. **Slow file search**: Update search exclude patterns

This setup provides a complete development environment optimized for building the secure data wiping GUI application.